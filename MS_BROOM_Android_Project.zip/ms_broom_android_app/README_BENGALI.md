# MS BROOM — Android APK project

এই প্রজেক্টটি `MS BROOM` নামে একটি Android WebView অ্যাপ তৈরি করে। এটি আপনার বর্তমান সাইট `https://msroom-official.netlify.app/` খোলে; পুরোনো `msbroom.netlify.app` সাইট ব্যবহার করে না। WhatsApp, ফোন এবং বাইরের ওয়েব লিংক Android-এর উপযুক্ত অ্যাপে খোলার চেষ্টা করে।

## APK তৈরি করার ফ্রি পদ্ধতি (GitHub Actions)

1. GitHub-এ সাইন ইন করে একটি নতুন repository তৈরি করুন, যেমন `ms-broom-android`।
2. এই ZIP-এর ফাইলগুলো extract করে সব ফাইল repository-তে upload/commit করুন। `.github/workflows/build-apk.yml`-সহ সব ফাইল রাখবেন।
3. GitHub repository-র **Actions** tab খুলুন।
4. **Build MS BROOM APK** workflow নির্বাচন করে **Run workflow** চাপুন।
5. সফল হলে workflow run খুলে **Artifacts** থেকে `MS-BROOM-debug-APK` ডাউনলোড করুন। ZIP-এর ভেতরে `app-debug.apk` থাকবে।
6. APK নিজের Android ফোনে কপি করে খুলুন। ফোনে চাইলে “Install unknown apps” অনুমতি দিতে হবে। শুধু নিজের বিশ্বাসযোগ্য APK-ই ইনস্টল করবেন।

## Android Studio দিয়ে

1. Android Studio ইনস্টল করুন (ফ্রি)।
2. Extract করা `ms_broom_android_app` ফোল্ডারটি Open করুন।
3. Android SDK Platform 35 ও JDK 17 ইনস্টল/নির্বাচিত আছে নিশ্চিত করুন।
4. Gradle sync শেষ হলে **Build > Build APK(s)** নির্বাচন করুন।
5. APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## গুরুত্বপূর্ণ

- এই পরিবেশে Android SDK/Gradle build চালানো যায়নি, তাই এই ZIP-টি **source project**, APK ফাইল নয়। APK পেতে উপরের বিল্ড ধাপ সম্পন্ন করতে হবে।
- অ্যাপটি ইন্টারনেট ব্যবহার করে বর্তমান ওয়েবসাইট দেখায়; ওয়েবসাইটে পরিবর্তন হলে অ্যাপেও তা দেখা যাবে। এটি সম্পূর্ণ offline অ্যাপ নয়।
- Debug APK ব্যক্তিগত পরীক্ষা করার জন্য। Play Store প্রকাশের জন্য আলাদা signing/release build, Google Play Developer account এবং Google-এর বর্তমান testing/publishing requirements লাগতে পারে।
